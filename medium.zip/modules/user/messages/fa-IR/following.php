<?php
return [
    '_follow.unfollow'          =>  'دنبال شده',
    '_follow.follow'            =>  'دنبال کن',
    'following.header'          =>  'دنبال شدگان توسط ',
    'followers.header'          =>  'دنبال کنندگان ',
    'following.head.title'      =>  'دنبال شدگان توسط {name} - '.Yii::t('app','title'),
    'followers.head.title'      =>  'دنبال کنندگان {name} - '.Yii::t('app','title'),
];