<?php
return [
    '_admin.attr.user'          =>  'کاربر',
    'comment.attr.user_id'      =>  'کاربر',
    'comment.attr.post_id'      =>  'نوشته',
    'comment.attr.text'         =>  'نظر',
    'comment.attr.created_at'   =>  'نوشته شده در',
    '_admin.btn.trash.title'    =>  'عدم نمایش',
    '_admin.btn.untrash.title'  =>  'نمایش',
    '_admin.btn.abuse.title'    =>  'گزارش سو استفاده',
    'post.comment'              =>  'ارسال نظر',
    'admin.head.title'          =>  'مدیریت نظرها',
];