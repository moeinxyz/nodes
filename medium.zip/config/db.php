<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=medium',
    'emulatePrepare' => true,    
    'username' => 'root',
    'password' => 'hitler2014',
    'charset' => 'utf8',
//    'enableSchemaCache' => true,    
    'tablePrefix' => 'tbl_',    
];
