<?php

return [
    'adminEmail'            =>  'moein7tl@gmail.com',
    'embedlyKeys'           =>  ['a06a9e786a354857962ab68ca89a2406'],
    'linkedinCallbackUrl'   =>  'http://nodes.ir/medium/web/social/auth?authclient=linkedin',
    'noreply-email'         =>  'noreply@nodes.ir',
    'twitterHandler'        =>  '@nodesir',
    'wildcat_urls'  =>  [
        'posts',
        'recommends',
        'rss',
        'followers',
        'following',
    ]
];
